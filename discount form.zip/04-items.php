
<?php

session_start();


?>
<!DOCTYPE html>
<html>
<head>
	<style> 
		input[type='number'] { 
   
    	-moz-appearance: textfield;
   
		}

	</style>
</head>
<body>

<?php
	if (isset($_SESSION['abou'])) {

?>
		<form  action="05-calculation.php" method="POST" class="price" >

			<input type="text"  name="price" placeholder="ENTER PRICE"   >
			<input type="text" name="amount" placeholder="ENTER AMOUNT" >
			<input type="submit" name="select" value="SELECT">

		</form>
<?php
	}else{
		
		echo "<script> location.href='01-login.php'</script>";

	
}
?>

</body>
</html>
	






<!-- pattern="\d+" min="0" -->

