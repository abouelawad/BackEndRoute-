<form action="02-handel-login.php" method="POST">
	
	<input type="text" name="username" placeholder="username">
	
	<input type="password" name="password" placeholder="password">
	<input type="submit" value="submit">
</form>

