<?php


$username = 'abou';
$password = 'abou';

session_start();


if (isset($_SESSION['abou'])) {

	echo "welcome mr. " . $_SESSION['abou'] . "<br>";

	echo "<a href='04-items.php'>Go Check Items</a>" ;

}else{
	if($_POST['username'] == $username  && $_POST['password'] == $password  ){

		$_SESSION['abou'] = $username;
		echo "welcome mr. " . $_SESSION['abou']  . "<br>";
		echo "<a href='04-items.php'>Gooo Check Items</a>" ;



		
		// echo "<script>location.href='03-welcome.php'</script>" ; 
	}else{
		

		echo "<script> alert('username or password incorrect!')</script>";

		echo "<script>location.href='01-login.php'</script>";
	}
}